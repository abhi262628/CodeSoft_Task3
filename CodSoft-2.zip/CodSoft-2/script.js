const display = document.getElementById('display');
let currentInput = '';
let operator = '';
let firstValue = '';

const buttons = document.querySelectorAll('.btn');
buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.getAttribute('data-value');
        const action = button.getAttribute('data-action');

        if (value) {
            currentInput += value;
            display.innerText = firstValue + operator + currentInput;
        } else if (action) {
            handleAction(action);
        }
    });
});

function handleAction(action) {
    switch (action) {
        case 'clear':
            currentInput = '';
            firstValue = '';
            operator = '';
            display.innerText = '0';
            break;
        case 'delete':
            if (currentInput !== '') {
                currentInput = currentInput.slice(0, -1);
            } else if (operator !== '') {
                operator = '';
            } else if (firstValue !== '') {
                firstValue = firstValue.slice(0, -1);
            }
            display.innerText = firstValue + operator + currentInput || '0';
            break;
        case 'add':
            setOperator('+');
            break;
        case 'subtract':
            setOperator('-');
            break;
        case 'multiply':
            setOperator('*');
            break;
        case 'divide':
            setOperator('/');
            break;
        case 'calculate':
            if (firstValue && operator && currentInput) {
                const result = calculate(parseFloat(firstValue), parseFloat(currentInput), operator);
                display.innerText = firstValue + operator + currentInput + '=' + result;
                currentInput = result.toString();
                firstValue = '';
                operator = '';
            }
            break;
    }
}

function setOperator(op) {
    if (currentInput === '' && operator !== '') {
        operator = op;
        display.innerText = firstValue + operator;
    } else if (firstValue === '') {
        firstValue = currentInput;
        operator = op;
        currentInput = '';
        display.innerText = firstValue + operator;
    } else if (currentInput !== '') {
        firstValue = calculate(parseFloat(firstValue), parseFloat(currentInput), operator).toString();
        operator = op;
        currentInput = '';
        display.innerText = firstValue + operator;
    }
}

function calculate(a, b, operator) {
    switch (operator) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            return a / b;
        default:
            return b;
    }
}  